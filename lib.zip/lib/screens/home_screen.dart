import 'package:flutter/material.dart';
import 'package:power/screens/add_device_screen.dart';
import 'package:provider/provider.dart';

import '../providers/device_provider.dart';
import '../models/power_data.dart';

// Utility function to calculate cost based on kWh units
double calculateCost(double units) {
  if (units <= 1500) {
    return units * 10;
  } else if (units <= 3000) {
    return 1500 * 10 + (units - 1500) * 35;
  } else if (units <= 4000) {
    return 1500 * 10 + 1500 * 35 + (units - 3000) * 80;
  } else {
    return 1500 * 10 + 1500 * 35 + 1000 * 80 + (units - 4000) * 120;
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF111B22),
      appBar: AppBar(
        title: const Text('Energy Monitor'),
        backgroundColor: const Color(0xFF111B22),
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const AddDeviceScreen()),
              );
            },
          ),
        ],
      ),
      body: Consumer<DeviceProvider>(
        builder: (context, deviceProvider, _) {
          // No devices: prompt to add
          if (deviceProvider.devices.isEmpty) {
            return Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.add),
                label: const Text('Add Device'),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => const AddDeviceScreen()),
                  );
                },
              ),
            );
          }

          // Get latest reading
          final reading =
              deviceProvider.powerDataList.isNotEmpty
                  ? deviceProvider.powerDataList.last
                  : null;
          if (reading == null) {
            return const Center(
              child: Text(
                'No data available',
                style: TextStyle(color: Colors.white),
              ),
            );
          }

          final totalUsage = reading.energy; // kWh
          final cost = calculateCost(totalUsage);

          return Padding(
            padding: const EdgeInsets.all(16),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Top cards: Current, Energy, Cost
                  GridView.count(
                    crossAxisCount:
                        MediaQuery.of(context).size.width > 600 ? 3 : 2,
                    crossAxisSpacing: 16,
                    mainAxisSpacing: 16,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _InfoCard(
                        icon: Icons.electric_bolt,
                        iconColor: const Color(0xFF47A9EA),
                        label: 'Current',
                        value: '${reading.current.toStringAsFixed(2)} A',
                      ),
                      _InfoCard(
                        icon: Icons.bolt,
                        iconColor: Colors.white,
                        label: 'Energy',
                        value: '${totalUsage.toStringAsFixed(2)} kWh',
                      ),
                      _InfoCard(
                        icon: Icons.payments,
                        iconColor: Colors.white,
                        label: 'Cost',
                        value: '${cost.toStringAsFixed(0)} IQD',
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const Text(
                    'Real-time Data',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  // Secondary metrics grid
                  GridView.count(
                    crossAxisCount: 2,
                    crossAxisSpacing: 1,
                    mainAxisSpacing: 1,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      _DataTile(
                        label: 'Voltage',
                        value: '${reading.voltage.toStringAsFixed(1)} V',
                      ),
                      _DataTile(
                        label: 'Current',
                        value: '${reading.current.toStringAsFixed(2)} A',
                      ),
                      _DataTile(
                        label: 'Power',
                        value: '${reading.power.toStringAsFixed(1)} W',
                      ),
                      _DataTile(
                        label: 'Energy',
                        value: '${reading.energy.toStringAsFixed(2)} kWh',
                      ),
                      _DataTile(
                        label: 'Frequency',
                        value: '${reading.frequency.toStringAsFixed(1)} Hz',
                      ),
                      _DataTile(
                        label: 'Power Factor',
                        value: reading.powerFactor.toStringAsFixed(2),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  // Top-level cards
  Widget _InfoCard({
    required IconData icon,
    required Color iconColor,
    required String label,
    required String value,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xFF1A2932),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.2),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      padding: const EdgeInsets.all(16),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, size: 40, color: iconColor),
          const SizedBox(height: 8),
          Text(
            label,
            style: const TextStyle(fontSize: 14, color: Color(0xFF93B3C8)),
          ),
          Text(
            value,
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: iconColor,
            ),
          ),
        ],
      ),
    );
  }

  // Secondary data tiles
  Widget _DataTile({required String label, required String value}) {
    return Container(
      color: const Color(0xFF1A2932),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 12, color: Color(0xFF93B3C8)),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(fontSize: 16, color: Colors.white),
          ),
        ],
      ),
    );
  }
}
